# my_robot_description
- storagy urdf업로드, 가제보 실행시 storagy urdf를 업로드하고 보여준다.

