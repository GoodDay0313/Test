# My Robot Gazebo
- Gazebo 런치 xml파일: ros2 launch my_robot_gazebo launch_sim.launch.xml