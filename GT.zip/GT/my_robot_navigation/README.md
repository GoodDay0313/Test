# My Robot Navigation
- Navigation할 때 쓰이는 xml, python파일들(기능은 같음)
- Navigatioin lauch :

    - ros2 launch my_robot_navigation bringup_launch.xml 또는 
    - ros2 launch my_robot_navigation bringup_launch.py    
